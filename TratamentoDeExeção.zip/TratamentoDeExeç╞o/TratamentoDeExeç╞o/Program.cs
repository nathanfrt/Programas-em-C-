﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TratamentoDeExeção.QUESTÃO_1;
using TratamentoDeExeção.QUESTÃO_2;
using TratamentoDeExeção.QUESTÃO_3;
using TratamentoDeExeção.QUESTÃO_4;

namespace TratamentoDeExeção
{
    class Program
    {
        static void Main(string[] args)
        {
            // Alunos: Nathan Freitas e Marco Túlio

            Console.WriteLine("QUESTÃO 1 \n\n");
            Teste01.testeQ1();

            Console.WriteLine("_________________________________________");
            Console.WriteLine("\n \n QUESTÃO 2 \n\n");
            Teste02.testeQ2();

            Console.WriteLine("_________________________________________");
            Console.WriteLine("\n \n QUESTÃO 3 \n\n");
            Teste03.testeQ3();

            Console.WriteLine("_________________________________________");
            Console.WriteLine("\n \n QUESTÃO 4 \n\n");
            Teste04.testeQ4();

            Console.ReadKey();

        }

    }
}
