﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TratamentoDeExeção.QUESTÃO_1
{
    class Inteiro
    {               
        public void validar()
        {
            try
            {
                int divisores = 0;

                Console.Write("Digite um número para verificar se é PRIMO: ");
                int valor = int.Parse(Console.ReadLine());

                for (int i = 1; i < valor; i++)
                {
                    if (valor % i == 0)
                    {
                        divisores++;
                    }
                }

                if (divisores == 1)
                {
                    if (valor == 2)
                        Console.WriteLine("O número digitado NÃO é primo");

                    else
                    Console.WriteLine("O número digitado é primo");
                }
                else
                {
                    Console.WriteLine("O número digitado NÃO é primo");
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
