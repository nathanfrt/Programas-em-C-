﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TratamentoDeExeção.QUESTÃO_1
{
    class Teste01
    {
        public static void testeQ1()
        {           

            Inteiro inteiro = new Inteiro();
            inteiro.validar();
            Console.ReadKey();
            
        }
    }
}
