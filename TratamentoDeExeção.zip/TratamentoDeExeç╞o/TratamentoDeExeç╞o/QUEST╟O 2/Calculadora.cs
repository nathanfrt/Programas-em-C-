﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TratamentoDeExeção.QUESTÃO_2
{
    class Calculadora
    {              

        public int Soma(int a, int b)
        {
            return a + b;
        }

        public int Subtracao(int a, int b)
        {
            return a - b;
        }

        public double Divisao(double a, double b)
        {
            return a / b;
        }

        public double Multiplicacao(double a, double b)
        {
            return a * b;
        }

        public int Modulo(int a, int b)
        {
            return a % b;
        }


        
        public void validar(int digito)
        {
            try
            {
                if (digito == 1)
                {
                    Console.Write("Digite o primeiro valor: ");
                    int p = int.Parse(Console.ReadLine());

                    Console.Write("Digite o segundo valor: ");
                    int s = int.Parse(Console.ReadLine());

                    Console.WriteLine("Soma = " + Soma(p,s).ToString());
                    
                }

                else if (digito == 2)
                {
                    Console.Write("Digite o primeiro valor: ");
                    int p = int.Parse(Console.ReadLine());

                    Console.Write("Digite o segundo valor: ");
                    int s = int.Parse(Console.ReadLine());
                    Console.WriteLine("Subtração = " + Subtracao(p, s).ToString()); 
                }

                else if (digito == 3)
                {
                    Console.Write("Digite o primeiro valor: ");
                    int p = int.Parse(Console.ReadLine());

                    Console.Write("Digite o segundo valor: ");
                    int s = int.Parse(Console.ReadLine());
                    Console.WriteLine("Divisão = " + Divisao(p, s).ToString());
                }

                else if (digito == 4)
                {
                    Console.Write("Digite o primeiro valor: ");
                    int p = int.Parse(Console.ReadLine());

                    Console.Write("Digite o segundo valor: ");
                    int s = int.Parse(Console.ReadLine());
                    Console.WriteLine("Multiplicação = " + Multiplicacao(p, s).ToString());
                }

                else if (digito == 5)
                {
                    Console.Write("Digite o primeiro valor: ");
                    int p = int.Parse(Console.ReadLine());

                    Console.Write("Digite o segundo valor: ");
                    int s = int.Parse(Console.ReadLine());
                    Console.WriteLine("Módulo = " + Modulo(p, s).ToString());
                }
                else
                    Console.WriteLine("Digito inválido");
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
