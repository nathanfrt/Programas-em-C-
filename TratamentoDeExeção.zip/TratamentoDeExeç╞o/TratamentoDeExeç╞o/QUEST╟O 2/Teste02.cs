﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TratamentoDeExeção.QUESTÃO_2
{
    class Teste02
    {
        public static void testeQ2()
        {
            Console.Write("ESCOLHA A OPERAÇÃO DE CÁLCULO: " +
                "\n1 - SOMA " +
                "\n2 - SUBTRAÇÃO " + 
                "\n3 - DIVISÃO  " +
                "\n4 - MULTIPLICAÇÃO " +
                "\n5 - MÓDULO \n ");

            int digito = int.Parse(Console.ReadLine());

            Calculadora calc = new Calculadora();
            calc.validar(digito);

            Console.ReadKey();

        }
    }
}
