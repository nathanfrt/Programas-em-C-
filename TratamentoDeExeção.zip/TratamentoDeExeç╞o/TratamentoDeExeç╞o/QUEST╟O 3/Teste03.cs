﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TratamentoDeExeção.QUESTÃO_3
{
    class Teste03
    {
        public static void testeQ3()
        {
            Vetor vet = new Vetor();
            vet.inserir();          
            

            Console.ReadKey();
        }
    }
}
