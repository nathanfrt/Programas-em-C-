﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;




namespace TratamentoDeExeção.QUESTÃO_3
{
    class Vetor
    {
        int[] vetorzin = new int[10];      

        
        public void inserir()
        {           

            for (int i = 0; i < vetorzin.Length; i++)
            {                
                try 
                {
                    Console.WriteLine("Digite o valor na posição " + i + " : ");
                    vetorzin[i] = int.Parse(Console.ReadLine());
                }

                catch (FormatException ex)
                {
                    Console.WriteLine("O valor informado não é um número inteiro" + ex);                    
                }

                catch (IndexOutOfRangeException ind)
                {
                    Console.WriteLine("Posição inexistente" + ind);
                }
            }
        }
    }
}
