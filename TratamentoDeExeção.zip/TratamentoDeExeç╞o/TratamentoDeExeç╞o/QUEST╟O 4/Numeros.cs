﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TratamentoDeExeção.QUESTÃO_4
{
    class Numeros
    {

        public void soma()
        {
            try
            {
                Console.Write("Digite um número para ser adicionado: ");
                int num = int.Parse(Console.ReadLine());

                while (num <= 100)
                {
                    Console.Write("Digite um novo número: ");
                    int num2 = int.Parse(Console.ReadLine());

                    num += num2;
                    Console.WriteLine("Valor atual:" + num);
                }
            }
            catch (FormatException ex )
            {
                throw new Exception("Excecao acima de 100" + ex);
            }

            Console.ReadKey();
        }
    }
}
