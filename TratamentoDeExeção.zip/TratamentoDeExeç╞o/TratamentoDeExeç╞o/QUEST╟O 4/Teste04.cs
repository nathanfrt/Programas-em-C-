﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TratamentoDeExeção.QUESTÃO_4
{
    class Teste04
    {
        public static void testeQ4()
        {
            Numeros nuns = new Numeros();
            nuns.soma();
        }
    }
}
